--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_40af8255a0e398f6_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT djan_content_type_id_12bc336dba74f04d_fk_django_content_type_id;
ALTER TABLE ONLY public.core_story DROP CONSTRAINT core_story_genre_id_534521bac4fd74e6_fk_core_genre_id;
ALTER TABLE ONLY public.core_section_votes_cast DROP CONSTRAINT core_section_votes_cas_user_id_4091c3f9e4dc09b8_fk_auth_user_id;
ALTER TABLE ONLY public.core_section_votes_cast DROP CONSTRAINT core_section_vot_section_id_4ec28330627cbd10_fk_core_section_id;
ALTER TABLE ONLY public.core_section DROP CONSTRAINT core_section_user_id_5673b648fc447398_fk_auth_user_id;
ALTER TABLE ONLY public.core_section DROP CONSTRAINT core_section_story_id_21f2f3dded51d743_fk_core_story_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permiss_user_id_6fd1d63d46dc3bf0_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_u_permission_id_ecca18af50d0b0b_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_264c1b6ad78633e_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_d29cd7600f53196_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permission_id_45aa7a4c2d849b0e_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_group_id_661b284587c31d0b_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_content_type_id_58ea5b4e6a6e0646_fk_django_content_type_id;
DROP INDEX public.django_session_session_key_24c12bb112dc2559_like;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.core_story_slug_4d3773d1dca09e7_uniq;
DROP INDEX public.core_story_080a38f3;
DROP INDEX public.core_section_votes_cast_e8701ad4;
DROP INDEX public.core_section_votes_cast_730f6511;
DROP INDEX public.core_section_f5976bb5;
DROP INDEX public.core_section_e8701ad4;
DROP INDEX public.auth_user_username_782f26948866dce9_like;
DROP INDEX public.auth_user_user_permissions_e8701ad4;
DROP INDEX public.auth_user_user_permissions_8373b171;
DROP INDEX public.auth_user_groups_e8701ad4;
DROP INDEX public.auth_user_groups_0e939a4f;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
DROP INDEX public.auth_group_name_76834297f802289b_like;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_630c8b1f15ee5a7_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.core_story DROP CONSTRAINT core_story_slug_44d4810e44f35e9b_uniq;
ALTER TABLE ONLY public.core_story DROP CONSTRAINT core_story_pkey;
ALTER TABLE ONLY public.core_section_votes_cast DROP CONSTRAINT core_section_votes_cast_section_id_user_id_key;
ALTER TABLE ONLY public.core_section_votes_cast DROP CONSTRAINT core_section_votes_cast_pkey;
ALTER TABLE ONLY public.core_section DROP CONSTRAINT core_section_pkey;
ALTER TABLE ONLY public.core_genre DROP CONSTRAINT core_genre_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_permission_id_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_group_id_key;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.core_story ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.core_section_votes_cast ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.core_section ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.core_genre ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.core_story_id_seq;
DROP TABLE public.core_story;
DROP SEQUENCE public.core_section_votes_cast_id_seq;
DROP TABLE public.core_section_votes_cast;
DROP SEQUENCE public.core_section_id_seq;
DROP TABLE public.core_section;
DROP SEQUENCE public.core_genre_id_seq;
DROP TABLE public.core_genre;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: chrisrogers
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO chrisrogers;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: chrisrogers
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO chrisrogers;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO chrisrogers;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO chrisrogers;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO chrisrogers;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO chrisrogers;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO chrisrogers;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO chrisrogers;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO chrisrogers;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO chrisrogers;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO chrisrogers;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO chrisrogers;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO chrisrogers;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: core_genre; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE core_genre (
    id integer NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.core_genre OWNER TO chrisrogers;

--
-- Name: core_genre_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE core_genre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_genre_id_seq OWNER TO chrisrogers;

--
-- Name: core_genre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE core_genre_id_seq OWNED BY core_genre.id;


--
-- Name: core_section; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE core_section (
    id integer NOT NULL,
    body_content text NOT NULL,
    votes integer NOT NULL,
    status character varying(255) NOT NULL,
    story_id integer NOT NULL,
    user_id integer,
    "position" integer
);


ALTER TABLE public.core_section OWNER TO chrisrogers;

--
-- Name: core_section_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE core_section_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_section_id_seq OWNER TO chrisrogers;

--
-- Name: core_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE core_section_id_seq OWNED BY core_section.id;


--
-- Name: core_section_votes_cast; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE core_section_votes_cast (
    id integer NOT NULL,
    section_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.core_section_votes_cast OWNER TO chrisrogers;

--
-- Name: core_section_votes_cast_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE core_section_votes_cast_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_section_votes_cast_id_seq OWNER TO chrisrogers;

--
-- Name: core_section_votes_cast_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE core_section_votes_cast_id_seq OWNED BY core_section_votes_cast.id;


--
-- Name: core_story; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE core_story (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    genre_id integer,
    slug character varying(255)
);


ALTER TABLE public.core_story OWNER TO chrisrogers;

--
-- Name: core_story_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE core_story_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_story_id_seq OWNER TO chrisrogers;

--
-- Name: core_story_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE core_story_id_seq OWNED BY core_story.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO chrisrogers;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO chrisrogers;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO chrisrogers;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO chrisrogers;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO chrisrogers;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: chrisrogers
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO chrisrogers;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chrisrogers
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO chrisrogers;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_genre ALTER COLUMN id SET DEFAULT nextval('core_genre_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_section ALTER COLUMN id SET DEFAULT nextval('core_section_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_section_votes_cast ALTER COLUMN id SET DEFAULT nextval('core_section_votes_cast_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_story ALTER COLUMN id SET DEFAULT nextval('core_story_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY auth_group (id, name) FROM stdin;
\.
COPY auth_group (id, name) FROM '$$PATH$$/2377.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2379.dat';

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 2, true);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2375.dat';

--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('auth_permission_id_seq', 27, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/2381.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/2383.dat';

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('auth_user_id_seq', 5, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2385.dat';

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: core_genre; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY core_genre (id, title) FROM stdin;
\.
COPY core_genre (id, title) FROM '$$PATH$$/2394.dat';

--
-- Name: core_genre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('core_genre_id_seq', 8, true);


--
-- Data for Name: core_section; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY core_section (id, body_content, votes, status, story_id, user_id, "position") FROM stdin;
\.
COPY core_section (id, body_content, votes, status, story_id, user_id, "position") FROM '$$PATH$$/2392.dat';

--
-- Name: core_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('core_section_id_seq', 10, true);


--
-- Data for Name: core_section_votes_cast; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY core_section_votes_cast (id, section_id, user_id) FROM stdin;
\.
COPY core_section_votes_cast (id, section_id, user_id) FROM '$$PATH$$/2396.dat';

--
-- Name: core_section_votes_cast_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('core_section_votes_cast_id_seq', 9, true);


--
-- Data for Name: core_story; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY core_story (id, title, genre_id, slug) FROM stdin;
\.
COPY core_story (id, title, genre_id, slug) FROM '$$PATH$$/2390.dat';

--
-- Name: core_story_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('core_story_id_seq', 19, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2387.dat';

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 29, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY django_content_type (id, app_label, model) FROM stdin;
\.
COPY django_content_type (id, app_label, model) FROM '$$PATH$$/2373.dat';

--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('django_content_type_id_seq', 9, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY django_migrations (id, app, name, applied) FROM stdin;
\.
COPY django_migrations (id, app, name, applied) FROM '$$PATH$$/2371.dat';

--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chrisrogers
--

SELECT pg_catalog.setval('django_migrations_id_seq', 22, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: chrisrogers
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2388.dat';

--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: core_genre_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY core_genre
    ADD CONSTRAINT core_genre_pkey PRIMARY KEY (id);


--
-- Name: core_section_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY core_section
    ADD CONSTRAINT core_section_pkey PRIMARY KEY (id);


--
-- Name: core_section_votes_cast_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY core_section_votes_cast
    ADD CONSTRAINT core_section_votes_cast_pkey PRIMARY KEY (id);


--
-- Name: core_section_votes_cast_section_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY core_section_votes_cast
    ADD CONSTRAINT core_section_votes_cast_section_id_user_id_key UNIQUE (section_id, user_id);


--
-- Name: core_story_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY core_story
    ADD CONSTRAINT core_story_pkey PRIMARY KEY (id);


--
-- Name: core_story_slug_44d4810e44f35e9b_uniq; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY core_story
    ADD CONSTRAINT core_story_slug_44d4810e44f35e9b_uniq UNIQUE (slug);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_630c8b1f15ee5a7_uniq; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_630c8b1f15ee5a7_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: chrisrogers; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: auth_group_name_76834297f802289b_like; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_group_name_76834297f802289b_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_782f26948866dce9_like; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX auth_user_username_782f26948866dce9_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: core_section_e8701ad4; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX core_section_e8701ad4 ON core_section USING btree (user_id);


--
-- Name: core_section_f5976bb5; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX core_section_f5976bb5 ON core_section USING btree (story_id);


--
-- Name: core_section_votes_cast_730f6511; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX core_section_votes_cast_730f6511 ON core_section_votes_cast USING btree (section_id);


--
-- Name: core_section_votes_cast_e8701ad4; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX core_section_votes_cast_e8701ad4 ON core_section_votes_cast USING btree (user_id);


--
-- Name: core_story_080a38f3; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX core_story_080a38f3 ON core_story USING btree (genre_id);


--
-- Name: core_story_slug_4d3773d1dca09e7_uniq; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX core_story_slug_4d3773d1dca09e7_uniq ON core_story USING btree (slug);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_24c12bb112dc2559_like; Type: INDEX; Schema: public; Owner: chrisrogers; Tablespace: 
--

CREATE INDEX django_session_session_key_24c12bb112dc2559_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_content_type_id_58ea5b4e6a6e0646_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_content_type_id_58ea5b4e6a6e0646_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_661b284587c31d0b_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_661b284587c31d0b_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_45aa7a4c2d849b0e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_45aa7a4c2d849b0e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_d29cd7600f53196_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_d29cd7600f53196_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_264c1b6ad78633e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_264c1b6ad78633e_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_u_permission_id_ecca18af50d0b0b_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_u_permission_id_ecca18af50d0b0b_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_6fd1d63d46dc3bf0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_6fd1d63d46dc3bf0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_section_story_id_21f2f3dded51d743_fk_core_story_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_section
    ADD CONSTRAINT core_section_story_id_21f2f3dded51d743_fk_core_story_id FOREIGN KEY (story_id) REFERENCES core_story(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_section_user_id_5673b648fc447398_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_section
    ADD CONSTRAINT core_section_user_id_5673b648fc447398_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_section_vot_section_id_4ec28330627cbd10_fk_core_section_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_section_votes_cast
    ADD CONSTRAINT core_section_vot_section_id_4ec28330627cbd10_fk_core_section_id FOREIGN KEY (section_id) REFERENCES core_section(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_section_votes_cas_user_id_4091c3f9e4dc09b8_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_section_votes_cast
    ADD CONSTRAINT core_section_votes_cas_user_id_4091c3f9e4dc09b8_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_story_genre_id_534521bac4fd74e6_fk_core_genre_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY core_story
    ADD CONSTRAINT core_story_genre_id_534521bac4fd74e6_fk_core_genre_id FOREIGN KEY (genre_id) REFERENCES core_genre(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djan_content_type_id_12bc336dba74f04d_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT djan_content_type_id_12bc336dba74f04d_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_40af8255a0e398f6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: chrisrogers
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_40af8255a0e398f6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: chrisrogers
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM chrisrogers;
GRANT ALL ON SCHEMA public TO chrisrogers;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

